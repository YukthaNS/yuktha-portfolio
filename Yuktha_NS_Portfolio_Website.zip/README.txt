YUKTHA N S — PORTFOLIO WEBSITE

Files:
- index.html: the responsive portfolio website.

How to view:
1. Extract the ZIP file.
2. Open index.html in a browser (Chrome works well).

How to publish online for free with GitHub Pages:
1. Create/sign in to a GitHub account.
2. Create a repository named yuktha-portfolio (or another name).
3. Upload index.html.
4. Open the repository's Settings > Pages.
5. Choose the main branch and root folder, then save.
6. GitHub will provide a public website link when publishing finishes.

Before sharing with recruiters:
- Replace all square-bracket placeholders.
- Add your real email, LinkedIn, GitHub, graduation year, and confirmed skills.
- Add any Java projects and repository links when available.
- Verify project details and reported accuracy against your report.
